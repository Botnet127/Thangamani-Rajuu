# Thangamani Raju — Cybersecurity Analyst

Portfolio of Thangamani Raju, SOC Tier 1 & 2 analyst (Verizon, Chennai). Immediate joiner. Open to Dubai.

Live site: add your Vercel / custom domain here after deploy.

## Stack

TanStack Start, React, Tailwind CSS v4. Static résumé download, MITRE coverage, contact form (mailto).

## Deploy on Vercel

1. Push this repo to GitHub.
2. Go to [vercel.com](https://vercel.com) → **Add New → Project** → import this repo.
3. Leave build settings as detected (`npm run build`).
4. Deploy. You get a `*.vercel.app` URL in about a minute.
5. **Settings → Domains** to attach `yourname.com`. See Vercel’s [custom domain guide](https://vercel.com/docs/domains/working-with-domains/add-a-domain).

No environment variables required. Auth and database are off.

## Local

```bash
npm install
npm run dev
```
